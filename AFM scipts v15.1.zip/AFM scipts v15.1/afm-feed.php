<?php

// Provide feed list entries for AFM IPI for 16 students
// Odd blocks all even, even blocks all odd
// Called via URL. For example http://172.16.20.11/afm-feed.php?lab=1&student=8

function lab1($snum)
{
 if(($snum % 2) == 0){
  for($i=1; $i<16; $i+=2) {
   echo "10." . "10." . $i."." . "30,32\r\n";
  }
 exit(0);
 }else{
  for($i=2; $i<17; $i+=2) {
     echo "10." . "10." . $i."." . "30,32\r\n";
  }
 exit(0);
 }
}

function lab31($snum)
{
 if(($snum % 2) == 0){
  for($i=1; $i<16; $i+=2) {
   echo "10." . "10." . $i."." . "30,32,,my_category\r\n";
  }
 exit(0);
 }else{
  for($i=2; $i<17; $i+=2) {
     echo "10." . "10." . $i."." . "30,32,,my_category\r\n";
  }
 exit(0);
 }
}

function lab32($snum)
{
 if(($snum % 2) == 0){
  for($i=1; $i<16; $i+=2) {
   echo "10." . "10." . $i."." . "30,32,wl,white_category\r\n";
  }
 exit(0);
 }else{
  for($i=2; $i<17; $i+=2) {
     echo "10." . "10." . $i."." ."30,32,wl,white_category\r\n";
  }
 exit(0);
 }
}

function lab33($snum)
{
 if(($snum % 2) == 0){
  for($i=1; $i<16; $i+=2) {
   echo "10." . "10." . $i."." . "30,32,bl\r\n";
  }
 exit(0);
 }else{
  for($i=2; $i<17; $i+=2) {
     echo "10." . "10." . $i."." ."30,32,bl\r\n";
  }
 exit(0);
 }
}

$argument1 = $_GET['lab'];
$argument2 = $_GET['student'];

switch($argument1)
{
 case '1':
  lab1($argument2);
  break;
 case '31':
  lab31($argument2);
  break;
 case '32':
  lab32($argument2);
  break;
 case '33':
  lab33($argument2);
  break;
 default:
  break;
}
?>
