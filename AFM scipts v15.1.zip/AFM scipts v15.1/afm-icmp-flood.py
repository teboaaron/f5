#!/usr/bin/env python

import os, sys, socket, struct, select, time

ICMP_ECHO_REQUEST = 8


def checksum(source_string):
    sum = 0

    countTo = (len(source_string)/2)*2

    count = 0
    while count < countTo:
        thisVal = ord(source_string[count + 1])*256 + ord(source_string[count])
        sum = sum + thisVal
        sum = sum & 0xffffffff # Necessary?
        count = count + 2

    if countTo < len(source_string):
        sum = sum + ord(source_string[len(source_string) - 1])
        sum = sum & 0xffffffff # Necessary?

    sum = (sum >> 16)  +  (sum & 0xffff)
    sum = sum + (sum >> 16)
    answer = ~sum
    answer = answer & 0xffff
    answer = answer >> 8 | (answer << 8 & 0xff00)
    return answer

def ping(my_socket, dest_addr, ID):
    dest_addr  =  socket.gethostbyname(dest_addr)
    my_checksum = 0
    header = struct.pack("bbHHh", ICMP_ECHO_REQUEST, 0, my_checksum, ID, 1)
    bytesInDouble = struct.calcsize("d")
    data = (192 - bytesInDouble) * "Q"
    data = struct.pack("d", time.clock()) + data
    my_checksum = checksum(header + data)
    header = struct.pack("bbHHh", ICMP_ECHO_REQUEST, 0, socket.htons(my_checksum), ID, 1)
    packet = header + data
    my_socket.sendto(packet, (dest_addr, 1))


if __name__ == '__main__':
    if len(sys.argv) != 2:
    	print "Usage: " + sys.argv[0] + " <ip-address>"
	print "Version: AFM v15.1"
	sys.exit(0)

    icmp = socket.getprotobyname("icmp")
    my_socket = socket.socket(socket.AF_INET, socket.SOCK_RAW, icmp)

    my_ID = os.getpid() & 0xFFFF

    for i in range(10000):
        ping(my_socket, sys.argv[1], my_ID)
	time.sleep(0.00025)
	if i % 100 == 0:
	    sys.stdout.write("*")
	    sys.stdout.flush()

    print ""
    my_socket.close()
